// fade
var ele = document.querySelector('.t-fade');
var fade = bamboo(ele, 'fade', {
    autoPlay: false,
});

var ele = document.querySelector('.t-fade-reverse');
var fade = bamboo(ele, 'fade', {
    reverse: true,
});

var ele = document.querySelector('.t-fade-js');
var fade = bamboo(ele, 'fade', {
    jsAnime: true,
});

// roll
var ele = document.querySelector('.t-roll');
var roll = bamboo(ele, 'roll', {

});

var ele = document.querySelector('.t-roll-reverse');
var roll = bamboo(ele, 'roll', {
    reverse: true,
});

var ele = document.querySelector('.t-roll-js');
var roll = bamboo(ele, 'roll', {
    jsAnime: true,
});

var ele = document.querySelector('.t-roll-vertical');
var roll = bamboo(ele, 'roll', {
    vertical: true,
});

var ele = document.querySelector('.t-roll-js-vertical');
var roll = bamboo(ele, 'roll', {
    jsAnime: true,
    vertical: true,
});

// into
var ele = document.querySelector('.t-into');
var into = bamboo(ele, 'into', {

});

var ele = document.querySelector('.t-into-reverse');
var into = bamboo(ele, 'into', {
    reverse: true,
});

var ele = document.querySelector('.t-into-js');
var into = bamboo(ele, 'into', {
    jsAnime: true,
});

// blinds
var ele = document.querySelector('.t-blinds');
var blinds = bamboo(ele, 'blinds', {

});

var ele = document.querySelector('.t-blinds-reverse');
var blinds = bamboo(ele, 'blinds', {
    reverse: true,
});

var ele = document.querySelector('.t-blinds-js');
var blinds = bamboo(ele, 'blinds', {
    jsAnime: true,
});

// square
var ele = document.querySelector('.t-square');
var square = bamboo(ele, 'square', {});

var ele = document.querySelector('.t-square-reverse');
var square = bamboo(ele, 'square', {
    reverse: true,
});

var ele = document.querySelector('.t-square-js');
var square = bamboo(ele, 'square', {
    jsAnime: true,
});

var ele = document.querySelector('.t-style');
var fade = bamboo(ele, 'fade', {});

var ele = document.querySelector('.t-style-para');
var fade = bamboo(ele, 'fade', {
    dots: document.querySelector('.m-nav'),
    prev: document.querySelector('.m-prev'),
    next: document.querySelector('.m-next'),
});